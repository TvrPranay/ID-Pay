from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import mysql.connector
from mysql.connector import Error
import os
from datetime import datetime
import logging
import cv2
import numpy as np
from dbr import BarcodeReader, EnumImagePixelFormat

# Setup logging
logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.secret_key = os.urandom(24)

# MySQL Configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': 'TvrPranay@2',
    'database': 'idpay_db'
}

# Initialize Dynamsoft Barcode Reader
barcode_reader = BarcodeReader()
try:
    barcode_reader.init_license("t0068lQAAADPcDbUR1jCqc2xYeOC2EMeX3Iq+vV0mAsKjt8pnpXMPAIty6aQ5PlFdL2rzdotABQVEYWDjgEPtuLGUF7xZl3I=;t0068lQAAAK3PguQNErlCRTGFfuYoOWVKRqwHUPeg+S7Pc85rqaqjapxGy9Cn8fDBx7zLRqznKRcwAPGXmE1qYtEPkwxQkKU=")
except Exception as e:
    logger.error(f"Failed to initialize barcode reader license: {str(e)}")
    raise

settings_string = '''
{
    "Version": "3.0",
    "ImageParameter": {
        "BarcodeFormatIds": ["BF_CODE_128", "BF_EAN_13", "BF_CODE_39", "BF_ALL_1D", "BF_QR_CODE", "BF_DATA_MATRIX", "BF_PDF417", "BF_ALL_2D"],
        "ExpectedBarcodesCount": 1,
        "DeblurLevel": 9,
        "Timeout": 20000,
        "MaxAlgorithmThreadCount": 4,
        "RegionDefinitionNameArray": ["FullImage"],
        "MinBarcodeTextLength": 6,
        "MaxBarcodeTextLength": 100,
        "LocalizationModes": [{"Mode": "LM_SCAN_DIRECTLY"}, {"Mode": "LM_STATISTICS", "Threshold": 0.5}],
        "ColorClusteringModes": [{"Mode": "CCM_GENERAL_HSV"}],
        "ColorConversionModes": [{"Mode": "CCM_GENERAL"}]
    }
}
'''
barcode_reader.init_runtime_settings_with_string(settings_string, 0)

def get_db_connection():
    try:
        return mysql.connector.connect(**DB_CONFIG)
    except Error as e:
        logger.error(f"Error connecting to MySQL: {e}")
        return None

def init_db():
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("DROP TABLE IF EXISTS support_tickets, transactions, merchants, users")
            cursor.execute("""
                CREATE TABLE users (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(255) NOT NULL,
                    email VARCHAR(255) UNIQUE NOT NULL,
                    barcode VARCHAR(50) UNIQUE NOT NULL,
                    pin VARCHAR(4) NOT NULL,
                    balance DECIMAL(10, 2) DEFAULT 1000.00,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            cursor.execute("""
                CREATE TABLE merchants (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    name VARCHAR(255) NOT NULL,
                    email VARCHAR(255) UNIQUE NOT NULL,
                    password VARCHAR(255) NOT NULL,
                    balance DECIMAL(10, 2) DEFAULT 0.00,
                    account_status BOOLEAN DEFAULT TRUE
                )
            """)
            cursor.execute("""
                CREATE TABLE transactions (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    merchant_id INT,
                    user_id INT,
                    user_barcode VARCHAR(50),
                    amount DECIMAL(10, 2),
                    transaction_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                    transaction_type VARCHAR(50),
                    status VARCHAR(50) DEFAULT 'Completed',
                    FOREIGN KEY (merchant_id) REFERENCES merchants(id),
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """)
            cursor.execute("""
                CREATE TABLE support_tickets (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    merchant_id INT,
                    title VARCHAR(255),
                    description TEXT,
                    status VARCHAR(50) DEFAULT 'Open',
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (merchant_id) REFERENCES merchants(id)
                )
            """)
            cursor.execute("INSERT IGNORE INTO users (name, email, barcode, pin, balance) VALUES (%s, %s, %s, %s, %s)",
                          ("John Doe", "john@example.com", "USER123456", "1234", 1000.00))
            cursor.execute("INSERT IGNORE INTO merchants (name, email, password, balance) VALUES (%s, %s, %s, %s)",
                          ("Merchant One", "merchant@example.com", generate_password_hash("password123"), 0.00))
            connection.commit()
            logger.info("Database initialized successfully")
        except Error as e:
            logger.error(f"Error initializing database: {e}")
        finally:
            cursor.close()
            connection.close()

def scan_barcode(timeout=25):
    scanned_barcode = None
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        logger.error("Error: Webcam could not be opened.")
        return None

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    start_time = datetime.now()
    while (datetime.now() - start_time).seconds < timeout:
        ret, frame = cap.read()
        if not ret:
            logger.error("Failed to capture image.")
            break

        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        try:
            decoded_objects = barcode_reader.decode_buffer(frame_rgb, EnumImagePixelFormat.IPF_RGB_888)
            if decoded_objects and len(decoded_objects) > 0:
                barcode_data = decoded_objects[0].barcode_text.strip()
                if len(barcode_data) >= 6:
                    logger.info(f"Barcode Detected: {barcode_data}")
                    scanned_barcode = barcode_data
                    pts = decoded_objects[0].localization_result.localization_points
                    if len(pts) == 4:
                        pts_array = np.array(pts, dtype=np.int32)
                        cv2.polylines(frame, [pts_array], isClosed=True, color=(0, 255, 0), thickness=3)
                    break
        except Exception as e:
            logger.error(f"Error decoding barcode: {str(e)}")
            continue

        cv2.imshow('Barcode Scanner', frame)
        if cv2.waitKey(30) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    return scanned_barcode

@app.route('/')
def index():
    return redirect(url_for('login_merchant'))

@app.route('/login_merchant', methods=['GET', 'POST'])
def login_merchant():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        connection = get_db_connection()
        if connection:
            cursor = connection.cursor(dictionary=True)
            cursor.execute("SELECT * FROM merchants WHERE email = %s", (email,))
            merchant = cursor.fetchone()
            cursor.close()
            connection.close()
            if merchant and check_password_hash(merchant['password'], password):
                session['merchant_id'] = merchant['id']
                session['merchant_name'] = merchant['name']
                session['merchant_email'] = merchant['email']
                flash('Login successful!', 'success')
                return redirect(url_for('home_merchant'))
            else:
                flash('Invalid credentials', 'error')
    return render_template('login_merchant.html')

@app.route('/register_merchant', methods=['POST'])
def register_merchant():
    name = request.form.get('merchant_name')
    email = request.form.get('email')
    password = request.form.get('password')
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        try:
            cursor.execute("INSERT INTO merchants (name, email, password, balance) VALUES (%s, %s, %s, %s)",
                          (name, email, generate_password_hash(password), 0.00))
            connection.commit()
            flash('Registration successful! Please log in.', 'success')
        except mysql.connector.IntegrityError:
            flash('Email already registered', 'error')
        finally:
            cursor.close()
            connection.close()
    return redirect(url_for('login_merchant'))

@app.route('/logout')
def logout():
    session.clear()
    flash('Logged out successfully', 'success')
    return redirect(url_for('login_merchant'))

@app.route('/home_merchant')
def home_merchant():
    if 'merchant_id' not in session:
        return redirect(url_for('login_merchant'))

    connection = get_db_connection()
    if connection:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT name, email, balance, account_status FROM merchants WHERE id = %s", (session['merchant_id'],))
        merchant = cursor.fetchone()
        cursor.execute("SELECT COUNT(*) as total FROM transactions WHERE merchant_id = %s", (session['merchant_id'],))
        total_transactions = cursor.fetchone()['total']
        cursor.execute("SELECT amount, transaction_date FROM transactions WHERE merchant_id = %s ORDER BY transaction_date DESC LIMIT 1", 
                      (session['merchant_id'],))
        last_transaction = cursor.fetchone() or {'amount': 0.00, 'transaction_date': 'N/A'}
        cursor.execute("SELECT SUM(amount) as pending FROM transactions WHERE merchant_id = %s AND transaction_type = 'WITHDRAWAL' AND status = 'Pending'", 
                      (session['merchant_id'],))
        pending_withdrawals = cursor.fetchone()['pending'] or 0.00
        cursor.execute("SELECT user_barcode, amount, transaction_date, transaction_type, status FROM transactions WHERE merchant_id = %s ORDER BY transaction_date DESC LIMIT 5", 
                      (session['merchant_id'],))
        transactions = cursor.fetchall()
        cursor.close()
        connection.close()
        return render_template('home_merchant.html', 
                             merchant=merchant,
                             balance=merchant['balance'],
                             account_status=merchant['account_status'],
                             total_transactions=total_transactions,
                             last_transaction_amount=last_transaction['amount'],
                             last_transaction_date=last_transaction['transaction_date'],
                             pending_withdrawals=pending_withdrawals,
                             transactions=transactions)
    return "Database connection failed", 500

@app.route('/get_balance', methods=['GET'])
def get_balance():
    if 'merchant_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'}), 401
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT balance FROM merchants WHERE id = %s", (session['merchant_id'],))
        merchant = cursor.fetchone()
        cursor.close()
        connection.close()
        return jsonify({'success': True, 'balance': float(merchant['balance'])})
    return jsonify({'success': False, 'message': 'Database error'}), 500

@app.route('/check_barcode', methods=['POST'])
def check_barcode():
    if 'merchant_id' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized'})
    
    barcode = scan_barcode()
    if barcode:
        connection = get_db_connection()
        if connection:
            cursor = connection.cursor(dictionary=True)
            cursor.execute("SELECT id FROM users WHERE barcode = %s", (barcode,))
            user = cursor.fetchone()
            cursor.close()
            connection.close()
            if user:
                session['pending_barcode'] = barcode
                return jsonify({'success': True, 'barcode': barcode})
            return jsonify({'success': False, 'message': 'User not found'})
    return jsonify({'success': False, 'message': 'No barcode detected'})

@app.route('/verify_pin', methods=['POST'])
def verify_pin():
    if 'merchant_id' not in session or 'pending_barcode' not in session:
        return jsonify({'success': False, 'message': 'Unauthorized or no barcode scanned'})
    
    data = request.get_json()
    pin = data.get('pin')
    amount = float(data.get('amount'))
    
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT id, balance, pin FROM users WHERE barcode = %s", (session['pending_barcode'],))
        user = cursor.fetchone()
        if user and user['pin'] == pin:
            if user['balance'] >= amount:
                try:
                    cursor.execute("UPDATE users SET balance = balance - %s WHERE id = %s", (amount, user['id']))
                    cursor.execute("UPDATE merchants SET balance = balance + %s WHERE id = %s", 
                                  (amount, session['merchant_id']))
                    cursor.execute("INSERT INTO transactions (merchant_id, user_id, user_barcode, amount, transaction_type, status) VALUES (%s, %s, %s, %s, %s, %s)", 
                                  (session['merchant_id'], user['id'], session['pending_barcode'], amount, 'DEBIT', 'Completed'))
                    connection.commit()
                    transaction_id = cursor.lastrowid
                    session.pop('pending_barcode', None)
                    return jsonify({'success': True, 'message': 'Payment successful', 'transaction_id': transaction_id})
                except Error as e:
                    connection.rollback()
                    logger.error(f"Transaction error: {e}")
                    return jsonify({'success': False, 'message': 'Transaction failed'})
            else:
                return jsonify({'success': False, 'message': 'Insufficient user balance'})
        return jsonify({'success': False, 'message': 'Invalid PIN'})
    return jsonify({'success': False, 'message': 'Database error'})

@app.route('/withdraw', methods=['POST'])
def withdraw():
    if 'merchant_id' not in session:
        return redirect(url_for('login_merchant'))
    
    amount = float(request.form.get('amount'))
    account = request.form.get('account')  # Added to store withdrawal destination
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT balance FROM merchants WHERE id = %s", (session['merchant_id'],))
        merchant = cursor.fetchone()
        if merchant['balance'] >= amount:
            try:
                cursor.execute("UPDATE merchants SET balance = balance - %s WHERE id = %s", (amount, session['merchant_id']))
                cursor.execute("INSERT INTO transactions (merchant_id, amount, transaction_type, status, user_barcode) VALUES (%s, %s, %s, %s, %s)", 
                              (session['merchant_id'], amount, 'WITHDRAWAL', 'Pending', account))
                connection.commit()
                flash('Withdrawal request submitted', 'success')
            except Error as e:
                connection.rollback()
                logger.error(f"Withdrawal error: {e}")
                flash('Withdrawal failed', 'error')
        else:
            flash('Insufficient balance', 'error')
        cursor.close()
        connection.close()
    return redirect(url_for('home_merchant'))

@app.route('/preview_receipt/<int:transaction_id>')
def preview_receipt(transaction_id):
    if 'merchant_id' not in session:
        return redirect(url_for('login_merchant'))
    
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM transactions WHERE id = %s AND merchant_id = %s", 
                      (transaction_id, session['merchant_id']))
        transaction = cursor.fetchone()
        cursor.close()
        connection.close()
        if transaction:
            return render_template('receipt.html', transaction=transaction)
        return "No transaction found", 404
    return "Database error", 500

@app.route('/request_call', methods=['POST'])
def request_call():
    if 'merchant_id' not in session:
        return redirect(url_for('login_merchant'))
    
    phone_number = request.form.get('phone_number')
    flash(f'Call request to {phone_number} submitted', 'success')
    return redirect(url_for('home_merchant'))

@app.route('/send_email', methods=['POST'])
def send_email():
    if 'merchant_id' not in session:
        return redirect(url_for('login_merchant'))
    
    subject = request.form.get('subject')
    message = request.form.get('message')
    flash(f'Email with subject "{subject}" sent', 'success')
    return redirect(url_for('home_merchant'))

@app.route('/raise_ticket', methods=['POST'])
def raise_ticket():
    if 'merchant_id' not in session:
        return redirect(url_for('login_merchant'))
    
    title = request.form.get('title')
    description = request.form.get('description')
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        cursor.execute("INSERT INTO support_tickets (merchant_id, title, description) VALUES (%s, %s, %s)", 
                      (session['merchant_id'], title, description))
        connection.commit()
        flash('Support ticket raised successfully', 'success')
        cursor.close()
        connection.close()
    return redirect(url_for('home_merchant'))

@app.route('/update_profile', methods=['POST'])
def update_profile():
    if 'merchant_id' not in session:
        return redirect(url_for('login_merchant'))
    
    name = request.form.get('name')
    email = request.form.get('email')
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor()
        cursor.execute("UPDATE merchants SET name = %s, email = %s WHERE id = %s", 
                      (name, email, session['merchant_id']))
        connection.commit()
        session['merchant_name'] = name
        session['merchant_email'] = email
        flash('Profile updated successfully', 'success')
        cursor.close()
        connection.close()
    return redirect(url_for('home_merchant'))

@app.route('/change_password', methods=['POST'])
def change_password():
    if 'merchant_id' not in session:
        return redirect(url_for('login_merchant'))
    
    old_password = request.form.get('old_password')
    new_password = request.form.get('new_password')
    connection = get_db_connection()
    if connection:
        cursor = connection.cursor(dictionary=True)
        cursor.execute("SELECT password FROM merchants WHERE id = %s", (session['merchant_id'],))
        merchant = cursor.fetchone()
        if check_password_hash(merchant['password'], old_password):
            cursor.execute("UPDATE merchants SET password = %s WHERE id = %s", 
                          (generate_password_hash(new_password), session['merchant_id']))
            connection.commit()
            flash('Password changed successfully', 'success')
        else:
            flash('Incorrect old password', 'error')
        cursor.close()
        connection.close()
    return redirect(url_for('home_merchant'))

if __name__ == '__main__':
    init_db()
    app.run(debug=True, port=5008)