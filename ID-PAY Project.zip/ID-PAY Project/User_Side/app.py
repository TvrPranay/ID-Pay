from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import mysql.connector
import random
import string
from datetime import datetime, timedelta
import cv2
from pyzbar.pyzbar import decode
import numpy as np
import logging

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

MYSQL_CONFIG = {
    'user': 'root',
    'password': 'TvrPranay@2',
    'host': 'localhost',
    'database': 'id_users'
}

logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(levelname)s - %(message)s')

def init_db():
    conn = None
    cursor = None
    try:
        conn = mysql.connector.connect(
            user=MYSQL_CONFIG['user'],
            password=MYSQL_CONFIG['password'],
            host=MYSQL_CONFIG['host']
        )
        cursor = conn.cursor()
        cursor.execute('CREATE DATABASE IF NOT EXISTS id_users')
        conn.commit()

        conn = mysql.connector.connect(**MYSQL_CONFIG)
        cursor = conn.cursor()

        # Updated users table to include balance
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) UNIQUE NOT NULL,
                mobile VARCHAR(15) NOT NULL,
                password VARCHAR(255) NOT NULL,
                pin VARCHAR(4) NOT NULL,
                barcode VARCHAR(20) NOT NULL,
                balance DECIMAL(10, 2) DEFAULT 0.00,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS otp_requests (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                email VARCHAR(255) NOT NULL,
                otp VARCHAR(6) NOT NULL,
                expires_at TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS transactions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                type VARCHAR(50) NOT NULL,
                amount DECIMAL(10, 2) NOT NULL,
                method VARCHAR(50) NOT NULL,
                date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ''')

        cursor.execute('''
            CREATE TABLE IF NOT EXISTS tickets (
                ticket_id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                issue_type VARCHAR(50) NOT NULL,
                description TEXT NOT NULL,
                date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                status VARCHAR(20) DEFAULT 'Open',
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ''')

        # Add balance column if it doesn't exist
        cursor.execute("SHOW COLUMNS FROM users LIKE 'balance'")
        if not cursor.fetchone():
            cursor.execute("ALTER TABLE users ADD COLUMN balance DECIMAL(10, 2) DEFAULT 0.00")
            logging.info("Added 'balance' column to users table.")

        sample_user = ('John Doe', 'test@example.com', '1234567890', 'password123', '1234', '1234567890', 100.00)
        cursor.execute('INSERT IGNORE INTO users (name, email, mobile, password, pin, barcode, balance) VALUES (%s, %s, %s, %s, %s, %s, %s)', sample_user)
        conn.commit()
        print("MySQL database initialized with sample user.")
    except mysql.connector.Error as err:
        print(f"Error initializing database: {err}")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

with app.app_context():
    init_db()

def get_db_connection():
    return mysql.connector.connect(**MYSQL_CONFIG)

def generate_otp():
    return ''.join(random.choices(string.digits, k=6))

def scan_barcode(timeout=25):
    scanned_barcode = None
    cap = None
    try:
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            logging.warning("Default camera (index 0) not available, trying index 1...")
            cap.release()
            cap = cv2.VideoCapture(1)
            if not cap.isOpened():
                logging.error("No webcam available. Tried indices 0 and 1.")
                return None

        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        logging.info("Barcode scanner started with resolution 640x480.")

        start_time = datetime.now()
        max_duration = timeout

        while (datetime.now() - start_time).seconds < max_duration:
            ret, frame = cap.read()
            if not ret:
                logging.error("Failed to capture frame from webcam.")
                break

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            decoded_objects = decode(gray)

            if decoded_objects:
                for obj in decoded_objects:
                    barcode_data = obj.data.decode('utf-8')
                    barcode_type = obj.type
                    logging.info(f"Barcode Detected - Type: {barcode_type}, Data: {barcode_data}")

                    points = obj.polygon
                    if len(points) > 4:
                        hull = cv2.convexHull(np.array([point for point in points], dtype=np.float32))
                        cv2.polylines(frame, [hull], True, (0, 255, 0), 2)
                    else:
                        pts = np.array([(point.x, point.y) for point in points], dtype=np.int32)
                        cv2.polylines(frame, [pts], True, (0, 255, 0), 2)

                    x, y = points[0].x, points[0].y
                    cv2.putText(frame, barcode_data, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
                    
                    scanned_barcode = barcode_data
                    break

            if scanned_barcode:
                break

            cv2.imshow('Barcode Scanner', frame)
            key = cv2.waitKey(30) & 0xFF
            if key == ord('q'):
                logging.info("Scan interrupted by user with 'q' key.")
                break

    except Exception as e:
        logging.error(f"Error in barcode scanning: {str(e)}")
    finally:
        if cap is not None and cap.isOpened():
            cap.release()
        cv2.destroyAllWindows()

    logging.info(f"Scan complete: scanned_barcode={scanned_barcode}")
    return scanned_barcode

@app.route('/')
def welcome():
    return render_template('welcome.html')

@app.route('/index')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        mobile = request.form['mobile']
        password = request.form['password']
        pin = request.form['pin']
        barcode = request.form['barcode']

        if not (len(pin) == 4 and pin.isdigit()):
            return jsonify({'error': 'PIN must be a 4-digit number'}), 400

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute('SELECT * FROM users WHERE email = %s', (email,))
        if cursor.fetchone():
            conn.close()
            return jsonify({'error': 'Email already registered'}), 400

        cursor.execute('INSERT INTO users (name, email, mobile, password, pin, barcode) VALUES (%s, %s, %s, %s, %s, %s)',
                      (name, email, mobile, password, pin, barcode))
        conn.commit()
        cursor.execute('SELECT LAST_INSERT_ID() as id')
        user_id = cursor.fetchone()['id']
        conn.close()
        session['user_id'] = user_id
        return jsonify({'message': 'Registration successful', 'redirect': url_for('home')})
    return render_template('login.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        barcode = request.form['barcode']
        pin = request.form.get('pin', '')

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute('SELECT * FROM users WHERE email = %s AND barcode = %s', (email, barcode))
        user = cursor.fetchone()
        conn.close()

        if user and user['password'] == password and user['pin'] == pin:
            session['user_id'] = user['id']
            return jsonify({'message': 'Login successful', 'redirect': url_for('home')})
        else:
            return jsonify({'error': 'Invalid email, password, barcode, or PIN'}), 401
    return render_template('index.html')

@app.route('/forgot', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        otp = generate_otp()
        expires_at = datetime.utcnow() + timedelta(minutes=10)

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT id FROM users WHERE email = %s', (email,))
        user = cursor.fetchone()
        if user:
            cursor.execute('INSERT INTO otp_requests (user_id, email, otp, expires_at) VALUES (%s, %s, %s, %s)',
                          (user[0], email, otp, expires_at))
            conn.commit()
            print(f"OTP for {email}: {otp}")
        conn.close()
        return redirect(url_for('verify_otp'))
    return render_template('forgot.html')

@app.route('/verify_otp', methods=['GET', 'POST'])
def verify_otp():
    if request.method == 'POST':
        otp = request.form['otp']
        new_pin = request.form['new_pin']
        email = request.form['email']

        if not (len(new_pin) == 4 and new_pin.isdigit()):
            return render_template('verify_otp.html', error='New PIN must be a 4-digit number')

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT user_id FROM otp_requests WHERE email = %s AND otp = %s AND expires_at > NOW()', (email, otp))
        otp_record = cursor.fetchone()
        if otp_record:
            cursor.execute('UPDATE users SET pin = %s WHERE email = %s', (new_pin, email))
            cursor.execute('DELETE FROM otp_requests WHERE user_id = %s', (otp_record[0],))
            conn.commit()
        conn.close()
        return redirect(url_for('index'))
    return render_template('verify_otp.html')

@app.route('/home')
def home():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT name, email, pin, mobile FROM users WHERE id = %s', (session['user_id'],))
    user = cursor.fetchone()
    cursor.execute('SELECT type, date_time, amount, method FROM transactions WHERE user_id = %s', (session['user_id'],))
    transactions = cursor.fetchall()
    conn.close()
    
    return render_template('home.html', name=user['name'], email=user['email'], pin=user['pin'], 
                         phone=user['mobile'], transactions=transactions, session=session)

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('index'))

@app.route('/scan-barcode')
def scan_barcode_route():
    barcode = scan_barcode()
    if barcode:
        return jsonify({'status': 'success', 'barcode': barcode})
    return jsonify({'status': 'failure', 'message': 'No barcode detected'})

@app.route('/get_balance', methods=['POST'])
def get_balance():
    data = request.get_json()
    user_id = data.get('user_id')
    if not user_id or user_id != session.get('user_id'):
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT balance FROM users WHERE id = %s', (user_id,))
    user = cursor.fetchone()
    conn.close()
    
    if user:
        return jsonify({'status': 'success', 'balance': float(user['balance'])})
    return jsonify({'status': 'error', 'message': 'User not found'}), 404

from decimal import Decimal

@app.route('/top_up_wallet', methods=['POST'])
def top_up_wallet():
    data = request.get_json()
    logging.info(f"Received top-up request: {data}")
    user_id = data.get('user_id')
    amount_str = data.get('amount')
    method = data.get('method')
    logging.info(f"Session: {session}")
    logging.info(f"Session user_id: {session.get('user_id')}, Request user_id: {user_id}")
    if not user_id or str(user_id) != str(session.get('user_id')):
        logging.warning("Unauthorized top-up attempt")
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    try:
        amount = Decimal(amount_str)
    except (ValueError, DecimalException):
        logging.error("Invalid amount format")
        return jsonify({'status': 'error', 'message': 'Invalid amount format'}), 400
    if amount <= 0:
        logging.warning("Invalid amount for top-up")
        return jsonify({'status': 'error', 'message': 'Invalid amount'}), 400
    if method not in ['QR', 'UPI', 'Net Banking']:
        logging.warning("Invalid method for top-up")
        return jsonify({'status': 'error', 'message': 'Invalid payment method'}), 400
    # Ensure user_id is an integer
    try:
        user_id = int(user_id)
    except ValueError:
        logging.error("Invalid user_id format")
        return jsonify({'status': 'error', 'message': 'Invalid user_id'}), 400
    conn = get_db_connection()
    cursor = conn.cursor()
    # Check if user_id exists
    cursor.execute('SELECT id FROM users WHERE id = %s', (user_id,))
    if not cursor.fetchone():
        logging.error("User not found")
        return jsonify({'status': 'error', 'message': 'User not found'}), 404
    try:
        cursor.execute('UPDATE users SET balance = balance + %s WHERE id = %s', (amount, user_id))
        cursor.execute('INSERT INTO transactions (user_id, type, amount, method) VALUES (%s, %s, %s, %s)',
                      (user_id, 'Top Up', amount, method))
        conn.commit()
        logging.info(f"Successfully topped up user {user_id} with amount {amount}")
        return jsonify({'status': 'success', 'message': 'Wallet topped up successfully'})
    except mysql.connector.Error as err:
        conn.rollback()
        logging.error(f"Database error during top-up: {str(err)}")
        return jsonify({'status': 'error', 'message': f'Database error: {str(err)}'}), 500
    finally:
        cursor.close()
        conn.close()
@app.route('/send_money', methods=['POST'])
def send_money():
    data = request.get_json()
    user_id = data.get('user_id')
    recipient_email = data.get('recipient_email')
    amount = data.get('amount')

    if not user_id or user_id != session.get('user_id'):
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    if not recipient_email or not amount or amount <= 0:
        return jsonify({'status': 'error', 'message': 'Invalid email or amount'}), 400

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        # Check sender's balance
        cursor.execute('SELECT balance FROM users WHERE id = %s', (user_id,))
        sender = cursor.fetchone()
        if not sender or sender['balance'] < amount:
            return jsonify({'status': 'error', 'message': 'Insufficient balance'}), 400

        # Check recipient
        cursor.execute('SELECT id FROM users WHERE email = %s', (recipient_email,))
        recipient = cursor.fetchone()
        if not recipient:
            return jsonify({'status': 'error', 'message': 'Recipient not found'}), 404

        # Update balances
        cursor.execute('UPDATE users SET balance = balance - %s WHERE id = %s', (amount, user_id))
        cursor.execute('UPDATE users SET balance = balance + %s WHERE id = %s', (amount, recipient['id']))
        # Log transaction
        cursor.execute('INSERT INTO transactions (user_id, type, amount, method) VALUES (%s, %s, %s, %s)',
                      (user_id, 'Send', amount, 'Wallet'))
        cursor.execute('INSERT INTO transactions (user_id, type, amount, method) VALUES (%s, %s, %s, %s)',
                      (recipient['id'], 'Receive', amount, 'Wallet'))
        conn.commit()
        return jsonify({'status': 'success', 'message': 'Money sent successfully'})
    except mysql.connector.Error as err:
        conn.rollback()
        return jsonify({'status': 'error', 'message': f'Database error: {str(err)}'}), 500
    finally:
        cursor.close()
        conn.close()

@app.route('/request_money', methods=['POST'])
def request_money():
    data = request.get_json()
    user_id = data.get('user_id')
    requester_email = data.get('requester_email')
    amount = data.get('amount')

    if not user_id or user_id != session.get('user_id'):
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    if not requester_email or not amount or amount <= 0:
        return jsonify({'status': 'error', 'message': 'Invalid email or amount'}), 400

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    try:
        # Check requester
        cursor.execute('SELECT id FROM users WHERE email = %s', (requester_email,))
        requester = cursor.fetchone()
        if not requester:
            return jsonify({'status': 'error', 'message': 'Requester not found'}), 404

        # Log request as a transaction (for tracking purposes, not affecting balance yet)
        cursor.execute('INSERT INTO transactions (user_id, type, amount, method) VALUES (%s, %s, %s, %s)',
                      (user_id, 'Request Sent', amount, 'Wallet'))
        cursor.execute('INSERT INTO transactions (user_id, type, amount, method) VALUES (%s, %s, %s, %s)',
                      (requester['id'], 'Request Received', amount, 'Wallet'))
        conn.commit()
        return jsonify({'status': 'success', 'message': 'Money request sent successfully'})
    except mysql.connector.Error as err:
        conn.rollback()
        return jsonify({'status': 'error', 'message': f'Database error: {str(err)}'}), 500
    finally:
        cursor.close()
        conn.close()

@app.route('/get_latest_transactions', methods=['POST'])
def get_latest_transactions():
    data = request.get_json()
    user_id = data.get('user_id')
    last_id = data.get('last_id', 0)

    if not user_id or user_id != session.get('user_id'):
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT id, type, amount, method FROM transactions WHERE user_id = %s AND id > %s ORDER BY date_time DESC LIMIT 5', 
                   (user_id, last_id))
    transactions = cursor.fetchall()
    conn.close()

    return jsonify({'status': 'success', 'transactions': transactions})

@app.route('/chat_support', methods=['POST'])
def chat_support():
    data = request.get_json()
    user_id = data.get('user_id')
    message = data.get('message', '').lower()

    if not user_id or user_id != session.get('user_id'):
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)

    # Chatbot logic integrated with database
    if message in ["hi", "hello"]:
        response = "Hello! How can I assist you today?"
    elif message == "help":
        response = "I'm here to assist! You can ask about your balance, transactions, tickets, or anything else. Try 'balance', 'transactions', or 'tickets'."
    elif message == "balance":
        cursor.execute('SELECT balance FROM users WHERE id = %s', (user_id,))
        user = cursor.fetchone()
        response = f"Your current balance is ${user['balance'] if user else 0.00}."
    elif message == "transactions":
        cursor.execute('SELECT type, amount, method, date_time FROM transactions WHERE user_id = %s ORDER BY date_time DESC LIMIT 3', (user_id,))
        transactions = cursor.fetchall()
        if transactions:
            response = "Here are your recent transactions:\n" + "\n".join(
                [f"{tx['type']}: ${tx['amount']} via {tx['method']} on {tx['date_time']}" for tx in transactions]
            )
        else:
            response = "No recent transactions found."
    elif message == "tickets":
        cursor.execute('SELECT ticket_id, issue_type, status, date FROM tickets WHERE user_id = %s ORDER BY date DESC LIMIT 3', (user_id,))
        tickets = cursor.fetchall()
        if tickets:
            response = "Here are your recent tickets:\n" + "\n".join(
                [f"Ticket #{tx['ticket_id']} - {tx['issue_type']} ({tx['status']}) on {tx['date']}" for tx in tickets]
            )
        else:
            response = "No tickets found. Say 'raise ticket' to create one."
    elif message == "raise ticket":
        response = "Please use the 'Raise a Ticket' section on the support page to submit your issue."
    elif message in ["exit", "bye"]:
        response = "Goodbye! Chat session ended."
    else:
        response = "I didn't quite understand that. Try 'hello', 'help', 'balance', 'transactions', or 'tickets'."

    cursor.close()
    conn.close()
    return jsonify({'status': 'success', 'response': response})

@app.route('/raise_ticket', methods=['POST'])
def raise_ticket():
    data = request.get_json()
    user_id = data.get('user_id')
    issue_type = data['issue_type']
    description = data['description']

    if not user_id or user_id != session.get('user_id'):
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401
    if not issue_type or not description:
        return jsonify({'status': 'error', 'message': 'Issue type and description are required'}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT INTO tickets (user_id, issue_type, description, date, status)
            VALUES (%s, %s, %s, %s, %s)
        """, (user_id, issue_type, description, datetime.now(), "Open"))
        conn.commit()
        ticket_id = cursor.lastrowid
        return jsonify({"status": "success", "ticket_id": ticket_id})
    except mysql.connector.Error as err:
        conn.rollback()
        return jsonify({'status': 'error', 'message': f'Database error: {str(err)}'}), 500
    finally:
        cursor.close()
        conn.close()

@app.route('/get_ticket_history', methods=['POST'])
def get_ticket_history():
    data = request.get_json()
    user_id = data.get('user_id')

    if not user_id or user_id != session.get('user_id'):
        return jsonify({'status': 'error', 'message': 'Unauthorized'}), 401

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("""
        SELECT ticket_id, issue_type, description, date, status 
        FROM tickets WHERE user_id = %s ORDER BY date DESC
    """, (user_id,))
    tickets = cursor.fetchall()
    conn.close()
    return jsonify({"status": "success", "tickets": tickets})


if __name__ == '__main__':
    app.run(debug=True, port=5023)