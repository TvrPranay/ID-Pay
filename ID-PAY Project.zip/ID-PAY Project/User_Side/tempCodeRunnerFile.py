from flask import Flask, render_template, request, redirect, url_for, session, jsonify
import mysql.connector
import random
import string
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Change this to a secure key in production

# MySQL configuration
MYSQL_CONFIG = {
    'user': 'root',       # Replace with your MySQL username
    'password': 'TvrPranay@2',   # Replace with your MySQL password
    'host': 'localhost',
    'database': 'idpay_db'         # Database name
}

# Initialize database (run only once)
def init_db():
    conn = None
    cursor = None
    try:
        # Connect to MySQL server (without specifying a database initially)
        conn = mysql.connector.connect(
            user=MYSQL_CONFIG['user'],
            password=MYSQL_CONFIG['password'],
            host=MYSQL_CONFIG['host']
        )
        cursor = conn.cursor()

        # Create the database if it doesn't exist
        cursor.execute('CREATE DATABASE IF NOT EXISTS idpay_db')
        conn.commit()

        # Connect to the idpay_db database
        conn = mysql.connector.connect(**MYSQL_CONFIG)
        cursor = conn.cursor()

        # Create users table (storing plain PIN)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                email VARCHAR(255) UNIQUE NOT NULL,
                mobile VARCHAR(15) NOT NULL,
                pin VARCHAR(4) NOT NULL,  -- Plain 4-digit PIN
                barcode VARCHAR(20) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')

        # Create otp_requests table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS otp_requests (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                email VARCHAR(255) NOT NULL,
                otp VARCHAR(6) NOT NULL,
                expires_at TIMESTAMP NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ''')

        # Create transactions table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS transactions (
                id INT AUTO_INCREMENT PRIMARY KEY,
                user_id INT NOT NULL,
                type VARCHAR(50) NOT NULL,
                amount DECIMAL(10, 2) NOT NULL,
                method VARCHAR(50) NOT NULL,
                date_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
            )
        ''')

        # Insert a sample user (email: test@example.com, pin: 1234, barcode: 1234567890)
        sample_user = ('John Doe', 'test@example.com', '1234567890', '1234', '1234567890')
        cursor.execute('INSERT IGNORE INTO users (name, email, mobile, pin, barcode) VALUES (%s, %s, %s, %s, %s)', sample_user)

        conn.commit()
        print("MySQL database initialized with sample user.")
    except mysql.connector.Error as err:
        print(f"Error initializing database: {err}")
    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

# Call init_db once when the app starts
with app.app_context():
    init_db()

# Database connection function
def get_db_connection():
    conn = mysql.connector.connect(**MYSQL_CONFIG)
    return conn

# Generate OTP
def generate_otp():
    return ''.join(random.choices(string.digits, k=6))

# Welcome page
@app.route('/')
def welcome():
    return render_template('welcome.html')

# Index page (Sign In/Sign Up)
@app.route('/index')
def index():
    return render_template('index.html')

# Register page
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        mobile = request.form['mobile']
        pin = request.form['pin']
        barcode = request.form['barcode']

        # Validate PIN is 4 digits
        if not (len(pin) == 4 and pin.isdigit()):
            return render_template('login.html', error='PIN must be a 4-digit number')

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute('SELECT * FROM users WHERE email = %s', (email,))
        if cursor.fetchone():
            conn.close()
            return render_template('login.html', error='Email already registered')

        cursor.execute('INSERT INTO users (name, email, mobile, pin, barcode) VALUES (%s, %s, %s, %s, %s)',
                       (name, email, mobile, pin, barcode))
        conn.commit()
        cursor.execute('SELECT LAST_INSERT_ID() as id')
        user_id = cursor.fetchone()['id']
        conn.close()
        session['user_id'] = user_id  # Store user ID in session
        return redirect(url_for('home'))

    return render_template('login.html')

# Login authentication
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        barcode = request.form['barcode']
        pin = request.form.get('pin', '')  # Get PIN from form (added to index.html)

        conn = get_db_connection()
        cursor = conn.cursor(dictionary=True)
        cursor.execute('SELECT * FROM users WHERE email = %s AND barcode = %s', (email, barcode))
        user = cursor.fetchone()
        conn.close()

        if user and user['pin'] == pin:  # Compare plain PIN
            session['user_id'] = user['id']
            return redirect(url_for('home'))
        else:
            return render_template('index.html', error='Invalid email, barcode, or PIN')

    return render_template('index.html')

# Forgot Password
@app.route('/forgot', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        otp = generate_otp()
        expires_at = datetime.utcnow() + timedelta(minutes=10)  # OTP valid for 10 minutes

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT id FROM users WHERE email = %s', (email,))
        user = cursor.fetchone()
        if user:
            cursor.execute('INSERT INTO otp_requests (user_id, email, otp, expires_at) VALUES (%s, %s, %s, %s)',
                          (user[0], email, otp, expires_at))
            conn.commit()
            # In a real app, send OTP via email
            print(f"OTP for {email}: {otp}")  # Replace with email sending logic
        conn.close()
        return redirect(url_for('verify_otp'))

    return render_template('forgot.html')

# Verify OTP and Reset Password
@app.route('/verify_otp', methods=['GET', 'POST'])
def verify_otp():
    if request.method == 'POST':
        otp = request.form['otp']
        new_password = request.form['new_password']
        email = request.form['email']  # Assuming email is passed or retrieved

        # Validate new PIN is 4 digits
        if not (len(new_password) == 4 and new_password.isdigit()):
            return render_template('verify_otp.html', error='New PIN must be a 4-digit number')

        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT user_id FROM otp_requests WHERE email = %s AND otp = %s AND expires_at > NOW()', (email, otp))
        otp_record = cursor.fetchone()
        if otp_record:
            cursor.execute('UPDATE users SET pin = %s WHERE email = %s', (new_password, email))  # Update PIN
            cursor.execute('DELETE FROM otp_requests WHERE user_id = %s', (otp_record[0],))
            conn.commit()
            # Verify the update
            cursor.execute('SELECT pin FROM users WHERE email = %s', (email,))
            updated_pin = cursor.fetchone()[0]
            print(f"PIN updated to: {updated_pin}")  # Debug print
        conn.close()
        return redirect(url_for('index'))

    return render_template('verify_otp.html')

# Reset PIN
@app.route('/reset_pin', methods=['POST'])
def reset_pin():
    if 'user_id' not in session:
        return jsonify({'status': 'failure', 'message': 'Please log in to reset PIN'})

    data = request.get_json()
    user_id = data.get('user_id')
    current_pin = data.get('current_pin')
    new_pin = data.get('new_pin')

    if not all([user_id, current_pin, new_pin]) or len(new_pin) != 4 or not new_pin.isdigit():
        return jsonify({'status': 'failure', 'message': 'New PIN must be a 4-digit number'})

    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT pin FROM users WHERE id = %s', (user_id,))
    user = cursor.fetchone()

    if not user or user['pin'] != current_pin:
        conn.close()
        return jsonify({'status': 'failure', 'message': 'Current PIN is incorrect'})

    cursor.execute('UPDATE users SET pin = %s WHERE id = %s', (new_pin, user_id))
    conn.commit()
    conn.close()
    return jsonify({'status': 'success', 'message': 'PIN reset successful'})

# Barcode scanning (simulated)
@app.route('/scan-barcode')
def scan_barcode():
    # Simulate barcode scanning (replace with actual hardware integration)
    return jsonify({'barcode': '1234567890'})

# Process Transaction
@app.route('/process_transaction', methods=['POST'])
def process_transaction():
    data = request.get_json()
    user_id = data.get('user_id')
    amount = data.get('amount')
    method = data.get('method')

    if not all([user_id, amount, method]):
        return jsonify({'status': 'failure', 'message': 'Missing required fields'})

    try:
        amount = float(amount)  # Convert amount to float for decimal storage
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT INTO transactions (user_id, type, amount, method) VALUES (%s, %s, %s, %s)',
                       (user_id, 'Wallet Top-Up', amount, method))
        conn.commit()
        conn.close()
        return jsonify({'status': 'success'})
    except ValueError:
        return jsonify({'status': 'failure', 'message': 'Invalid amount format'})
    except mysql.connector.Error as err:
        return jsonify({'status': 'failure', 'message': f'Database error: {err}'})

# Home page (Dashboard)
@app.route('/home')
def home():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT name, email, pin FROM users WHERE id = %s', (session['user_id'],))  # Fetch plain PIN
    user = cursor.fetchone()
    
    # Fetch transaction history
    cursor.execute('SELECT type, date_time, amount, method FROM transactions WHERE user_id = %s', (session['user_id'],))
    transactions = cursor.fetchall()
    conn.close()
    
    return render_template('home.html', name=user['name'], email=user['email'], pin=user['pin'], transactions=transactions, user_id=session['user_id'])

# Profile data route (for the dropdown)
@app.route('/get_profile')
def get_profile():
    if 'user_id' not in session:
        return jsonify({'error': 'Not logged in'}), 401
    
    conn = get_db_connection()
    cursor = conn.cursor(dictionary=True)
    cursor.execute('SELECT name, email, pin FROM users WHERE id = %s', (session['user_id'],))  # Fetch plain PIN
    user = cursor.fetchone()
    conn.close()
    
    return jsonify({'name': user['name'], 'email': user['email'], 'pin': user['pin']})  # Return plain PIN

@app.route('/update_profile', methods=['POST'])
def update_profile():
    if 'merchant_id' not in session:
        return jsonify({'success': False, 'message': 'Please log in to update profile'}), 401

    data = request.get_json()
    merchant_id = session['merchant_id']
    new_phone = data.get('phone')
    new_profile_pic_url = data.get('profile_pic_url')

    conn = get_db_connection()
    cursor = conn.cursor()
    try:
        if new_phone and len(new_phone) >= 10 and new_phone.replace('+', '').isdigit():
            cursor.execute("UPDATE merchants SET mobile = %s WHERE id = %s", (new_phone, merchant_id))
        if new_profile_pic_url:
            cursor.execute("UPDATE merchants SET profile_pic_url = %s WHERE id = %s", (new_profile_pic_url, merchant_id))
        conn.commit()
        return jsonify({'success': True, 'message': 'Profile updated successfully'})
    except mysql.connector.Error as err:
        conn.rollback()
        return jsonify({'success': False, 'message': f'Error updating profile: {err}'})
    finally:
        cursor.close()
        conn.close()

# Logout route
@app.route('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, port=5012)